# Data Intensive - Prediction Basketball Games

Prediction of NBA basketball games outcome.
