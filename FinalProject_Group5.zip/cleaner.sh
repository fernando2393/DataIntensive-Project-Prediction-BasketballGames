#!/bin/bash
find . -name "*.crc" -type f -delete
find . -name "*_SUCCESS*" -type f -delete